<?php
/**
 * Create Custom Rest API End Points.
 */

 if ( ! class_exists( 'class_weawp_api_routes' ) ) {
    class class_weawp_api_routes {

        public function __construct() {
            add_action( 'rest_api_init', [ $this, 'create_rest_api_routes' ] );
        }

        public function create_rest_api_routes() {

            register_rest_route( 'weawp/v1', '/settings', [
                'methods' => 'POST',
                'callback' => [ $this, 'weawp_store_settings' ],
                'permission_callback' => [ $this, 'weawp_store_settings_permission' ]
            ] );

            register_rest_route( 'weawp/v1', '/search', [
                'methods' => 'GET',
                'callback' => [ $this, 'weawp_get_search' ],
                'permission_callback' => [ $this, 'weawp_get_search_permission' ]
            ]);

            register_rest_route( 'weawp/v1', '/search-data', [
                'methods' => 'POST',
                'callback' => [ $this, 'weawp_get_search_data' ],
                'permission_callback' => [ $this, 'weawp_get_search_data_permission' ]
            ]);
            
            register_rest_route( 'weawp/v1', '/search-link', [
                'methods' => 'POST',
                'callback' => [ $this, 'weawp_get_search_link' ],
                'permission_callback' => [ $this, 'weawp_get_search_link_permission' ]
            ]);

            register_rest_route( 'weawp/v1', '/analytics-data', [
                'methods' => 'GET',
                'callback' => [ $this, 'weawp_get_analytics_data' ],
                'permission_callback' => [ $this, 'weawp_get_analytics_data_permission' ]
            ]);

            register_rest_route( 'weawp/v1', '/database_indexes', [
                'methods' => 'POST',
                'callback' => [ $this, 'weawp_database_indexes' ],
                'permission_callback' => [ $this, 'weawp_database_indexes_permission' ]
            ]);

            register_rest_route( 'weawp/v1', '/analytics', [
                'methods' => 'POST',
                'callback' => [ $this, 'weawp_analytics' ],
                'permission_callback' => [ $this, 'weawp_analytics_permission' ]
            ]);

            register_rest_route( 'weawp/v1', '/analytics-data-reset', [
                'methods' => 'POST',
                'callback' => [ $this, 'weawp_analytics_data_reset' ],
                'permission_callback' => [ $this, 'weawp_analytics_data_reset_permission' ]
            ]);
        }

        private function weawp_get_data()
        {

            $_rq = $_REQUEST;
            global $wpdb;
            $search_text = isset($_rq['search']) ? strtolower(trim($_rq['search'])) : '';
            $search_in_description = isset($_rq['search_in_description']) ? $_rq['search_in_description'] : '';
            $display_only_instock = isset($_rq['display_only_instock']) ? (int)$_rq['display_only_instock'] : 0;
            $search_by_sku = isset($_rq['search_by_sku']) ? $_rq['search_by_sku'] : '0';
            $website_serach_max_cards = isset($_rq['website_serach_max_cards']) ? (int)$_rq['website_serach_max_cards'] : 1000000;
            $website_serach_max_links = isset($_rq['website_serach_max_links']) ? (int)$_rq['website_serach_max_links'] : 1000000;
            $content_type_active_ar = isset($_rq['content_type']) ? $_rq['content_type'] : array();
            $data_constraint = isset($_rq['data']) ? $_rq['data'] : '';
            $display_content_rows = isset($_rq['display_content_rows']) ? (int)$_rq['display_content_rows'] : 2;
            $display_product_categories = isset($_rq['display_product_categories']) ? (int)$_rq['display_product_categories'] : 0;
            $search_in_product_category = isset($_rq['search_in_product_category']) ? (int)$_rq['search_in_product_category'] : 0;
            $search_product_attributes = isset($_rq['search_product_attributes']) ? $_rq['search_product_attributes'] : array();

            $data_constraint = '';
            if (isset($_rq['data'])) {
                $data_constraint = $_rq['data'];
                if ($data_constraint === 'application') {
                    $website_serach_max_cards = 1000000;
                    $website_serach_max_links = 1000000;
                }
            }

            $content_type_active = array();
            $content_type_active["Product Categories"] = in_array("Product Categories", $content_type_active_ar) || $data_constraint === 'application' ? true : false; 
            $content_type_active["Product Tags"] = in_array("Product Tags", $content_type_active_ar) || $data_constraint === 'application' ? true : false; 
            $content_type_active["Categories"] = in_array("Categories", $content_type_active_ar) || $data_constraint === 'application' ? true : false; 
            $content_type_active["Tags"] = in_array("Tags", $content_type_active_ar) || $data_constraint === 'application' ? true : false; 
            $content_type_active["Products"] = in_array("Products", $content_type_active_ar) || $data_constraint === 'application' ? true : false; 
            $content_type_active["Pages"] = in_array("Pages", $content_type_active_ar) || $data_constraint === 'application' ? true : false; 
            $content_type_active["Blog"] = in_array("Blog", $content_type_active_ar) || $data_constraint === 'application' ? true : false; 

            if ($content_type_active["Product Categories"]) {
                $product_cat = get_terms('product_cat');
                $product_cat = array_values($product_cat);
                $product_cat_ar = array();

                foreach ($product_cat as $row) {
                    $item = array();
                    if (!empty($search_text)) {
                        if (strpos(strtolower($row->name), $search_text ) !== false) {
                            $item['name'] = $row->name;
                            $product_cat_ar[] = $item;
                        }
                    } else {
                        $item['name'] = $row->name;
                        $product_cat_ar[] = $item;
                    }
                }
            }

            if ($content_type_active["Product Tags"]) {

                $product_tag = get_terms( 'product_tag' );
                $product_tag_ar = array();

                foreach ($product_tag as $row) {
                    $item = array();
                    if (!empty($search_text)) {
                        if (strpos(strtolower($row->name), $search_text) !== false) {
                            $item['name'] = $row->name;
                            $product_tag_ar[] = $item;
                        }
                    } else {
                        $item['name'] = $row->name;
                        $product_tag_ar[] = $item;
                    }
                }
            }

            if ($content_type_active["Categories"]) {

                if (!empty($search_text)) {
                    $categories = get_categories(["hide_empty" => 0, 's' => $search_text]);
                } else {
                    $categories = get_categories(["hide_empty" => 0]);
                }

                $categories_ar = array();
        
                foreach ($categories as $category) {
                    $item = array();

                    if (!empty($search_text)) {
                        if (strpos(strtolower($category->name), $search_text) !== false) {
                            $item['name'] = $category->name;
                            $item['url'] = get_category_link($category->term_id);
                            $categories_ar[] = $item;
                        }
                    } else {
                        $item['name'] = $category->name;
                        $item['url'] = get_category_link($category->term_id);
                        $categories_ar[] = $item;
                    }
                }
            }
    
            if ($content_type_active["Tags"]) {
                $tags = get_tags(["hide_empty" => 0]);
                $tags_ar = array();

                foreach ($tags as $tag) {
                    $item = array();
                    if (!empty($search_text)) {
                        if (strpos(strtolower($tag->name), $search_text) !== false) {
                            $item['name'] = $tag->name;
                            $item['url'] = get_category_link($tag->term_id);
                            $tags_ar[] = $item;
                        }
                    } else {
                        $item['name'] = $tag->name;
                        $item['url'] = get_tag_link($tag->term_id);
                        $tags_ar[] = $item;
                    }
                }
        }

        if ($content_type_active["Products"]) {

                if (!empty($search_text)) {
                    $sql_search_condition = " AND p.post_title LIKE '%s' ";
                    $sql_input = ['%'.$search_text.'%'];

                } else {
                    $sql_search_condition = "";
                    $sql_input = [];
                }

                $SQL = "SELECT p.ID, p.post_title, p.post_content, p.post_status, p.post_date,
                        MAX(CASE WHEN pm.meta_key = '_price' then pm.meta_value ELSE NULL END) as price,
                        MAX(CASE WHEN pm.meta_key = '_regular_price' then pm.meta_value ELSE NULL END) as regular_price,
                        MAX(CASE WHEN pm.meta_key = '_sale_price' then pm.meta_value ELSE NULL END) as sale_price,
                        MAX(CASE WHEN pm.meta_key = '_sku' then pm.meta_value ELSE NULL END) as sku 
                            FROM " . $wpdb->prefix . "posts p
                            LEFT JOIN " . $wpdb->prefix . "postmeta as pm ON p.ID = pm.post_id
                            WHERE p.post_type in('product', 'product_variation')
                            AND p.post_status = 'publish'
                            " . $sql_search_condition . "
                            GROUP BY p.ID, p.post_title
                            ORDER BY p.post_date DESC";
                        // LIMIT %d";

                $products = $wpdb->get_results($wpdb->prepare($SQL, $sql_input));

                // var_dump($products); exit;
                
                $product_count = count($products);
                $products = array_slice($products, 0, $website_serach_max_cards);

                if ( $search_in_description == "1" && count($products) < $website_serach_max_cards ) {

                    if (!empty($search_text)) {
                        $sql_search_condition = " AND p.post_content LIKE '%s' ";
                        $sql_input = ['%'.$search_text.'%'];
        
                    } else {
                        $sql_search_condition = "";
                        $sql_input = [];
                        // $sql_input = [$website_serach_max_cards];
                    }

                    $SQL = "SELECT p.ID, p.post_title, p.post_content, p.post_status, p.post_date,
                            MAX(CASE WHEN pm.meta_key = '_price' then pm.meta_value ELSE NULL END) as price,
                            MAX(CASE WHEN pm.meta_key = '_regular_price' then pm.meta_value ELSE NULL END) as regular_price,
                            MAX(CASE WHEN pm.meta_key = '_sale_price' then pm.meta_value ELSE NULL END) as sale_price,
                            MAX(CASE WHEN pm.meta_key = '_sku' then pm.meta_value ELSE NULL END) as sku 
                                FROM " . $wpdb->prefix . "posts p
                                LEFT JOIN " . $wpdb->prefix . "postmeta as pm ON p.ID = pm.post_id
                                WHERE p.post_type in('product', 'product_variation')
                                AND p.post_status = 'publish'
                                " . $sql_search_condition . "
                                GROUP BY p.ID, p.post_title
                                ORDER BY p.post_date DESC";
                            // LIMIT %d";
        
                    $products_content_match = $wpdb->get_results($wpdb->prepare($SQL, $sql_input));
                    $product_count += count($products_content_match);
                    $products = array_merge($products, $products_content_match);
                    $products = array_slice($products, 0, $website_serach_max_cards);

                }

                if ( $search_by_sku == "1" && count($products) < $website_serach_max_cards ) {

                    $SQL = "SELECT p.ID, p.post_title, p.post_content, p.post_status, p.post_date,
                        MAX(CASE WHEN pm.meta_key = '_price' then pm.meta_value ELSE NULL END) as price,
                        MAX(CASE WHEN pm.meta_key = '_regular_price' then pm.meta_value ELSE NULL END) as regular_price,
                        MAX(CASE WHEN pm.meta_key = '_sale_price' then pm.meta_value ELSE NULL END) as sale_price,
                        MAX(CASE WHEN pm.meta_key = '_sku' then pm.meta_value ELSE NULL END) as sku 
                            FROM " . $wpdb->prefix . "posts p
                            INNER JOIN " . $wpdb->prefix . "postmeta as pm
                                ON p.ID = pm.post_id
                            WHERE p.post_type in('product', 'product_variation')
                            AND p.post_status = 'publish'
                            AND p.ID IN (select post_id from " . $wpdb->prefix . "postmeta where meta_key = '_sku'and meta_value LIKE '%s' )
                            GROUP BY p.ID, p.post_title
                            ORDER BY p.post_date DESC";

                    $products_sku_match = $wpdb->get_results($wpdb->prepare($SQL, ['%'.$search_text.'%'] ));

                    $product_count += count($products_sku_match);
                    $products = array_merge($products, $products_sku_match);
                    $products = array_slice($products, 0, $website_serach_max_cards);

                }

                if (count($search_product_attributes) > 0 && count($products) < $website_serach_max_cards ) {

                    $SQL = "SELECT p.ID, p.post_title, p.post_content, p.post_status, p.post_date,
                        MAX(CASE WHEN pm.meta_key = '_price' then pm.meta_value ELSE NULL END) as price,
                        MAX(CASE WHEN pm.meta_key = '_regular_price' then pm.meta_value ELSE NULL END) as regular_price,
                        MAX(CASE WHEN pm.meta_key = '_sale_price' then pm.meta_value ELSE NULL END) as sale_price,
                        MAX(CASE WHEN pm.meta_key = '_sku' then pm.meta_value ELSE NULL END) as sku 
                            FROM " . $wpdb->prefix . "posts p
                            INNER JOIN " . $wpdb->prefix . "postmeta as pm
                                ON p.ID = pm.post_id
                            WHERE p.post_type in('product', 'product_variation')
                            AND p.post_status = 'publish'
                            AND p.ID IN (
                                SELECT ID
                                FROM " . $wpdb->prefix . "posts
                                LEFT JOIN " . $wpdb->prefix . "term_relationships ON (" . $wpdb->prefix . "posts.ID = " . $wpdb->prefix . "term_relationships.object_id)
                                LEFT JOIN " . $wpdb->prefix . "term_taxonomy ON (" . $wpdb->prefix . "term_relationships.term_taxonomy_id = " . $wpdb->prefix . "term_taxonomy.term_taxonomy_id)
                                LEFT JOIN " . $wpdb->prefix . "terms ON (" . $wpdb->prefix . "term_taxonomy.term_taxonomy_id = " . $wpdb->prefix . "terms.term_id)
                                WHERE " . $wpdb->prefix . "terms.name LIKE '%s' 
                                AND " . $wpdb->prefix . "term_taxonomy.taxonomy IN ('pa_" . implode('\',\'pa_', $search_product_attributes). "')
                            )
                            GROUP BY p.ID, p.post_title
                            ORDER BY p.post_date DESC";

                    $products_attribute_match = $wpdb->get_results($wpdb->prepare($SQL, ['%'.$search_text.'%'] ));

                    $product_count += count($products_attribute_match);
                    $products = array_merge($products, $products_attribute_match);
                    $products = array_slice($products, 0, $website_serach_max_cards);

                }

                if ($search_in_product_category == 1 && count($products) < $website_serach_max_cards ) {
                    $SQL = "SELECT p.ID, p.post_title, p.post_content, p.post_status, p.post_date,
                        MAX(CASE WHEN pm.meta_key = '_price' then pm.meta_value ELSE NULL END) as price,
                        MAX(CASE WHEN pm.meta_key = '_regular_price' then pm.meta_value ELSE NULL END) as regular_price,
                        MAX(CASE WHEN pm.meta_key = '_sale_price' then pm.meta_value ELSE NULL END) as sale_price,
                        MAX(CASE WHEN pm.meta_key = '_sku' then pm.meta_value ELSE NULL END) as sku 
                            FROM " . $wpdb->prefix . "posts p
                            INNER JOIN " . $wpdb->prefix . "postmeta as pm
                                ON p.ID = pm.post_id
                            WHERE p.post_status = 'publish'
                            AND p.post_type in('product', 'product_variation')
                            AND p.ID IN (
                                SELECT ID
                                FROM " . $wpdb->prefix . "posts
                                LEFT JOIN " . $wpdb->prefix . "term_relationships ON (" . $wpdb->prefix . "posts.ID = " . $wpdb->prefix . "term_relationships.object_id)
                                LEFT JOIN " . $wpdb->prefix . "term_taxonomy ON (" . $wpdb->prefix . "term_relationships.term_taxonomy_id = " . $wpdb->prefix . "term_taxonomy.term_taxonomy_id)
                                LEFT JOIN " . $wpdb->prefix . "terms ON (" . $wpdb->prefix . "term_taxonomy.term_taxonomy_id = " . $wpdb->prefix . "terms.term_id)
                                WHERE " . $wpdb->prefix . "terms.name LIKE '%s'
                                AND " . $wpdb->prefix . "term_taxonomy.taxonomy = 'product_cat'
                            )
                            GROUP BY p.ID, p.post_title
                            ORDER BY p.post_date DESC";

                    $products_category_match = $wpdb->get_results($wpdb->prepare($SQL, ['%'.$search_text.'%'] ));

                    $product_count += count($products_category_match);
                    $products = array_merge($products, $products_category_match);
                    $products = array_slice($products, 0, $website_serach_max_cards);

                }

                $data = array();
                $i = 0;

                foreach ($products as $item) {

                    $process_item = true;
                    $product_id = $item->ID;
                    $product = wc_get_product($product_id);

                    $stock_status = $product->get_stock_status();
                    if ($display_only_instock === "1" && $stock_status !== 'instock') {
                        $process_item = false;
                    }

                    if ($process_item) {
                        $data[$i] = $this->weawp_process_product_item($item, $search_in_description, $stock_status, $data_constraint, $display_content_rows, $display_product_categories, $search_in_product_category, $search_product_attributes);
                        $i++;
                    }
                }
            }

            if ($content_type_active["Blog"]) {

                if (!empty($search_text)) {
                    $sql_search_condition = " AND post_title LIKE '%s' ";
                    $sql_input = ['%'.$search_text.'%'];

                } else {
                    $sql_search_condition = "";
                    $sql_input = [];
                }

                $SQL = "SELECT ID, post_title, post_content, post_status, post_date
                        FROM " . $wpdb->prefix . "posts
                        WHERE post_type = 'post'
                        AND post_status = 'publish'
                        " . $sql_search_condition . "
                        ORDER BY post_date DESC";

                $blog_posts = $wpdb->get_results($wpdb->prepare($SQL, $sql_input));

                $blog_posts_count = count($blog_posts);
                $blog_posts = array_slice($blog_posts, 0, $website_serach_max_cards);
            
                if ( $search_in_description == "1" && count($blog_posts) < $website_serach_max_cards ) {

                    if (!empty($search_text)) {
                        $sql_search_condition = " AND post_content LIKE '%s' ";
                        $sql_input = ['%'.$search_text.'%'];
        
                    } else {
                        $sql_search_condition = "";
                        $sql_input = [];
                    }
        
                    $SQL = "SELECT ID, post_title, post_content, post_status, post_date
                            FROM " . $wpdb->prefix . "posts
                            WHERE post_type in('post')
                            AND post_status = 'publish'
                            " . $sql_search_condition . "
                            ORDER BY post_date DESC";
        
                    $blog_posts_content_match = $wpdb->get_results($wpdb->prepare($SQL, $sql_input));

                    $blog_posts_count += count($blog_posts_content_match);
                    $blog_posts = array_merge($blog_posts, $blog_posts_content_match);
                    $blog_posts = array_slice($blog_posts, 0, $website_serach_max_cards);

                }

                $blog_posts_filtered = array();

                foreach ($blog_posts as $blog_post) {
                    $item = array();
                    $item['name'] = $blog_post->post_title;
                    $item['type'] = 'blog post';
                    if ($data_constraint === 'application') {
                        $item['content'] = esc_attr($blog_post->post_content);
                    } else {
                        $item['content'] = substr(esc_attr($blog_post->post_content), 0, $display_content_rows >= 3 ? 750 : 250);
                    }
                    $item['date'] = $blog_post->post_date;
                    $item['link'] = get_permalink($blog_post->ID);
                    $item['featured_image'] = get_the_post_thumbnail_url($blog_post->ID, 'thumbnail');
                    $blog_posts_filtered[] = $item;
                }
            }

            if ($content_type_active["Pages"]) {

                if (!empty($search_text)) {
                    $sql_search_condition = " AND post_title LIKE '%s' ";
                    $sql_input = ['%'.$search_text.'%' ,  $website_serach_max_cards];

                } else {
                    $sql_search_condition = "";
                    $sql_input = [$website_serach_max_cards];
                }

                $SQL = "SELECT ID, post_title, post_content, post_status, post_date
                        FROM " . $wpdb->prefix . "posts
                        WHERE post_type in('page')
                        AND post_status = 'publish'
                        " . $sql_search_condition . "
                        ORDER BY post_date DESC
                        LIMIT %d";

                $pages = $wpdb->get_results($wpdb->prepare($SQL, $sql_input));
            
                if ( $search_in_description == "1" && count($pages) < $website_serach_max_cards ) {

                    if (!empty($search_text)) {
                        $sql_search_condition = " AND post_content LIKE '%s' ";
                        $sql_input = ['%'.$search_text.'%' ,  $website_serach_max_cards];
        
                    } else {
                        $sql_search_condition = "";
                        $sql_input = [$website_serach_max_cards];
                    }
        
                    $SQL = "SELECT ID, post_title, post_content, post_status, post_date
                            FROM " . $wpdb->prefix . "posts
                            WHERE post_type in('page')
                            AND post_status = 'publish'
                            " . $sql_search_condition . "
                            ORDER BY post_date DESC
                            LIMIT %d";
        
                    $pages_content_match = $wpdb->get_results($wpdb->prepare($SQL, $sql_input));

                    $pages = array_merge($pages, $pages_content_match);

                }

                $page_filtered_ar = array();
                foreach ($pages as $page) {

                    $item = array();
                    $item['name'] = $page->post_title;
                    $item['type'] = 'page';
                    if ($data_constraint === 'application') {
                        $item['content'] = esc_attr($page->post_content);
                    } else {
                        $item['content'] = substr(esc_attr($page->post_content), 0, $display_content_rows >= 3 ? 750 : 250);
                    }
                    $item['date'] = $page->post_date;
                    $item['link'] = get_permalink($page->ID);
                    $item['featured_image'] = get_the_post_thumbnail_url($page->ID, 'thumbnail');
                    $page_filtered_ar[] = $item;
                }
            }

            $response = array();
            $response['data'] = $content_type_active["Products"] ?  $data : [];
            $response['blog_posts'] = $content_type_active["Blog"] ? $blog_posts_filtered : [];
            $response['pages'] = $content_type_active["Pages"] ?  $page_filtered_ar : [];
            $response['data_count'] = $content_type_active["Products"] ?  $product_count : 0;
            $response['blog_posts_count'] = $content_type_active["Blog"] ?  $blog_posts_count : 0;
            $response['website_search_cards_count'] = $product_count + $blog_posts_count + count($page_filtered_ar);

            $response['product_categories'] =  $content_type_active["Product Categories"] ? array_slice($product_cat_ar, 0, $website_serach_max_links) : [];
            $response['product_tags'] =  $content_type_active["Product Tags"] ?  array_slice($product_tag_ar, 0, $website_serach_max_links) : [];
            $response['categories'] =  $content_type_active["Categories"] ?  array_slice($categories_ar, 0, $website_serach_max_links) : [];
            $response['tags'] =  $content_type_active["Tags"] ?  array_slice($tags_ar, 0, $website_serach_max_links) : [];

            return $response;
        }

        private function weawp_process_product_item($item, $search_in_description, $stock_status, $data_constraint, $display_content_rows, $display_product_categories, $search_in_product_category, $search_product_attributes) {

            $item_processed = array();

            $product_id = $item->ID;
            $product = wc_get_product($product_id);
                    
            $item_processed['id'] = $product_id;
            $item_processed['name'] = esc_attr($item->post_title);
            $item_processed['type'] = 'product';
            $item_processed['is_featured'] = esc_attr($product->get_featured());
            $product_cat_ids = wc_get_product_term_ids( $product_id, 'product_cat' );
            $product_tag_ids = wc_get_product_term_ids( $product_id, 'product_tag' );

            $item_processed['categories'] = $product_cat_ids;
            $item_processed['tags'] = $product_tag_ids;

            if ($data_constraint === 'application') {
                $item_processed['content'] = esc_attr($item->post_content);
            } else {
                $item_processed['content'] = substr(esc_attr($item->post_content), 0, $display_content_rows >= 3 ? 750 : 250);
            }

            $item_processed['link'] = get_permalink($product_id);
            $item_processed['sku'] = $item->sku;
            $item_processed['price'] = $item->price;
            $item_processed['price'] = $item->regular_price;
            if( $product->is_on_sale() ) {
                $item_processed['sale_price'] = true;
                $item_processed['sale_price_value'] = $item->sale_price;
                $item_processed['date_on_sale_from'] = $product->get_date_on_sale_from();
                $item_processed['date_on_sale_to'] = $product->get_date_on_sale_to();
            } else {
                $item_processed['sale_price'] = false;
                $item_processed['sale_price_value'] = '';
            }
            $item_processed['post_date'] = date($item->post_date);
            $item_processed['stock_status'] = $stock_status;  
            $item_processed['stock_quantity'] = $product->get_stock_quantity();
            $item_processed['reviews_allowed'] = $product->get_reviews_allowed();
            $item_processed['rating_items'] = !empty(count($product->get_rating_counts())) ? count($product->get_rating_counts()) : '';
            $item_processed['rating'] = $product->get_average_rating();
            $item_processed['featured_image']['thumbnail'] = get_the_post_thumbnail_url($product_id, 'thumbnail');
            $item_processed['featured_image']['medium'] = get_the_post_thumbnail_url($product_id, 'medium');
            $item_processed['featured_image']['large'] = get_the_post_thumbnail_url($product_id, 'large');
            $item_processed['add_to_cart_url'] = $product->add_to_cart_url();
            $attribute_items = [];
            $product_attributes = (array)$product->get_attributes();

            foreach ( $product_attributes as $key => $attribute ) {
                if (isset($attribute['name'])) {
                    $attribute['name_without_prefix_pa'] = str_replace('pa_', "", (string)$attribute['name']);
                    $attribute_items[ $attribute['name_without_prefix_pa']] = explode(',', trim($product->get_attribute($attribute['name'])));
                } else {
                    $attribute_items[$key] = explode(',', trim($product->get_attribute($key)));
                }
            }

            $item_processed['attributes'] = $attribute_items;
            
            if ($display_product_categories === 1) {
                $product_cat_ids = wc_get_product_term_ids($product_id, 'product_cat');
                foreach($product_cat_ids as $id) {
                    $term = get_term($id);
                    if (!empty($term)) {
                        $item_processed['product_category'][] = ['name'=> $term->name, 'id'=> $id];
                    }
                }
            }

            return $item_processed;
        }   


        public function weawp_get_search() {
            $timeProbe = weawp_microtime_float();
            $wc_options = get_option('woocommerce_permalinks');

            $output = array();
            $output['wpNonce'] = wp_create_nonce( 'wp_rest' );
            $output['data'] = $this->weawp_get_data();
            $output['time_api'] = weawp_microtime_float() - $timeProbe;
            $output['wp_custom_product_category_base_url'] = $wc_options['category_base'];
            $output['wp_custom_product_tag_base_url'] = $wc_options['tag_base'];
            $output['currency'] = get_woocommerce_currency_symbol();

            return rest_ensure_response( $output );

        }

        public function weawp_get_search_permission() {
            return true;
        }

        public function weawp_store_settings( $rq ) {
        
            $rq_settings = $rq['settings'];
            
            global $wpdb;
            $table  = $wpdb->prefix . 'weawp_search';
            $settingsDb = $wpdb->get_results("SELECT value FROM " . $table . " WHERE name = 'default-settings'");

            if (isset($settingsDb[0]->value) && $settingsDb[0]->value !== $rq_settings) {
                $wpdb->query( $wpdb->prepare("UPDATE $table 
                            SET value = %s 
                            WHERE name = %s", json_encode($rq_settings), 'default-settings') );
            } else {
                $wpdb->insert( $table, array(
                    'name' => 'default-settings', 
                    'value' => json_encode($rq_settings)),
                    array( '%s', '%s' ) ) ;
            }
        
            return rest_ensure_response( 'success' );
        }

        public function weawp_store_settings_permission() {
            return true;
        }

        

        public function weawp_get_search_data($_rq) {

            $search_term = isset($_rq['search_term']) ? strtolower(trim($_rq['search_term'])) : '';
            $uuid = isset($_rq['uuid']) ? $_rq['uuid'] :'';
            $displayed_items = isset($_rq['displayed_items']) ? strtolower(json_encode($_rq['displayed_items'])) : '';

            global $wpdb;
            $SQL = "INSERT INTO " . $wpdb->prefix . "weawp_search_log (search_term, uuid, displayed_items) VALUES (%s, %s, %s)";
            $db = $wpdb->get_results($wpdb->prepare($SQL, [$search_term, $uuid, $displayed_items]));
        }

        public function weawp_get_search_data_permission() {
            return true;
        }

        public function weawp_get_search_link($_rq) {

            $data = isset($_rq['data']) ? $_rq['data'] :'';
            global $wpdb;
            $SQL = "UPDATE " . $wpdb->prefix . "weawp_search_log 
                        SET item_id=%d, item_type=%s, item_link=%s 
                        WHERE uuid = %s";

            $db = $wpdb->get_results($wpdb->prepare($SQL, [$data['id'], $data['type'], $data['link'], $data['uuid']]));
        }

        public function weawp_get_search_link_permission() {
            return true;
        }

        public function weawp_get_analytics_data($_rq) {

            $timeProbe = weawp_microtime_float();

            $search_results = array();
            $search_terms_no_results = array();
            
            global $wpdb;

            $SQL = "SELECT search_term, count(*) AS count FROM " . $wpdb->prefix . "weawp_search_log
                        WHERE created_at >= DATE_ADD(CURDATE(), INTERVAL -7 DAY)
                        AND deleted_at is null
                        GROUP BY search_term
                        ORDER BY count DESC";
                    
            $search_results['last_7_days'] = $wpdb->get_results($wpdb->prepare($SQL));


            $SQL = "SELECT search_term, count(*) AS count FROM " . $wpdb->prefix . "weawp_search_log
                        WHERE created_at >= DATE_ADD(CURDATE(), INTERVAL -30 DAY)
                        AND deleted_at is null
                        GROUP BY search_term
                        ORDER BY count DESC";
                    
            $search_results['last_30_days'] = $wpdb->get_results($wpdb->prepare($SQL));


            $SQL = "SELECT search_term, count(*) AS count FROM " . $wpdb->prefix . "weawp_search_log
                        WHERE deleted_at is null
                        GROUP BY search_term
                        ORDER BY count DESC";
            
            $search_results['data'] = $wpdb->get_results($wpdb->prepare($SQL));


            $SQL = "SELECT search_term, count(*) AS count FROM " . $wpdb->prefix . "weawp_search_log
                    WHERE search_term NOT IN 
                        (SELECT search_term FROM " . $wpdb->prefix . "weawp_search_log
                            WHERE displayed_items IS NOT NULL AND displayed_items != '[]'
                            GROUP BY search_term
                        )
                    AND deleted_at is null
                    GROUP BY search_term
                    ORDER BY count DESC;";

            $search_terms_no_results['data'] = $wpdb->get_results($wpdb->prepare($SQL));

            $SQL = "SELECT search_term, count(*) AS count FROM " . $wpdb->prefix . "weawp_search_log
                    WHERE search_term NOT IN 
                        (SELECT search_term FROM " . $wpdb->prefix . "weawp_search_log
                            WHERE displayed_items IS NOT NULL AND displayed_items != '[]'
                            
                        AND created_at >= DATE_ADD(CURDATE(), INTERVAL -7 DAY)
                            GROUP BY search_term
                        )
                        
                    AND created_at >= DATE_ADD(CURDATE(), INTERVAL -7 DAY)
                    AND deleted_at is null
                    GROUP BY search_term
                    ORDER BY count DESC;";
                    
            $search_terms_no_results['last_7_days'] = $wpdb->get_results($wpdb->prepare($SQL));


            $SQL = "SELECT search_term, count(*) AS count FROM " . $wpdb->prefix . "weawp_search_log
                    WHERE search_term NOT IN 
                        (SELECT search_term FROM " . $wpdb->prefix . "weawp_search_log
                            WHERE displayed_items IS NOT NULL AND displayed_items != '[]'
                        AND created_at >= DATE_ADD(CURDATE(), INTERVAL -30 DAY)
                            GROUP BY search_term
                        )
                    AND created_at >= DATE_ADD(CURDATE(), INTERVAL -30 DAY)
                    AND deleted_at is null
                    GROUP BY search_term
                    ORDER BY count DESC;";
                    
            $search_terms_no_results['last_30_days'] = $wpdb->get_results($wpdb->prepare($SQL));


            $response = array();
            $response['last_7_days'] = $search_results['last_7_days'];
            $response['last_30_days'] = $search_results['last_30_days'];
            $response['data'] = $search_results['data'];
            $response['search_terms_no_results_data'] = $search_terms_no_results['data'];
            $response['search_terms_no_results_last_7_days'] = $search_terms_no_results['last_7_days'];
            $response['search_terms_no_results_last_30_days'] = $search_terms_no_results['last_30_days'];

            wp_send_json($response, $status_code=200 );

        }

        public function weawp_get_analytics_data_permission() {
            return true;
        }

        public function weawp_database_indexes( $rq ) {
        
            global $wpdb;

            $index_name = 'type_status_id';
            $SQL = "SHOW INDEX FROM " . $wpdb->prefix . "posts where Key_name = '" . $index_name . "';"; // no user input, sql injection prevention not required
            $indexdbExists = $wpdb->get_results($SQL);

            if ($wpdb->last_error) {
                return rest_ensure_response( 'error' );
            } else if (count($indexdbExists) > 0) {
                return rest_ensure_response("index with the same name \"" . $index_name . "\" exists in the database");
            }

            $SQL = "ALTER TABLE " . $wpdb->prefix . "posts
                    ADD INDEX `" . $index_name . "` (`post_type` ASC, `post_status` ASC, `id` ASC);";

            $indexdb = $wpdb->get_results($SQL);
            if ($wpdb->last_error) {
                return rest_ensure_response('error');
            } else {
                $SQL = "update " . $wpdb->prefix . "weawp_search set value = 1 WHERE name = 'database-indexes-applied';";
                $indexdbExists = $wpdb->get_results($SQL);
                return rest_ensure_response('success');
            }
        }

        public function weawp_database_indexes_permission() {
            return true;
        }

        public function weawp_analytics($_rq) {

            if (isset($_rq['analytics'])) {
            
                global $wpdb;
                $SQL = "UPDATE " . $wpdb->prefix . "weawp_search SET value = %s WHERE name = 'analytics';";

                $products = $wpdb->get_results($wpdb->prepare($SQL, json_encode($_rq['analytics'])));
            }
        }

        public function weawp_analytics_permission() {
            return true;
        }

        public function weawp_analytics_data_reset($_rq) {

            if (!empty($_rq['delete'])) {
            
                global $wpdb;
                $SQL = "UPDATE " . $wpdb->prefix . "weawp_search_log SET deleted_at = %s WHERE deleted_at is null ";

                $db = $wpdb->get_results($wpdb->prepare($SQL, date('Y-m-d H:i:s')));
            }
        }

        public function weawp_analytics_data_reset_permission() {
            return true;
        }

    }
}

new class_weawp_api_routes();