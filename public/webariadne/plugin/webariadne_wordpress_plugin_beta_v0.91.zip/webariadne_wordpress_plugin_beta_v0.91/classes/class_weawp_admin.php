<?php

 if ( ! class_exists( 'class_weawp_admin' ) ) {
    class class_weawp_admin {

        public function __construct() {
            add_action( 'admin_menu', [ $this, 'weawp_create_admin_menu' ] );
        }

        public function weawp_create_admin_menu() {
            $capability = 'manage_options';
            $slug = 'weawp-settings';

            add_menu_page(
                __( 'WebAriadne', 'wp-react-kickoff' ),
                __( 'WebAriadne', 'wp-react-kickoff' ),
                $capability,
                $slug,
                [ $this, 'weawp_menu_page_template' ],
                'dashicons-migrate'
            );
        }

        public function weawp_menu_page_template() {

            // try {
           
                $timeProbe = weawp_microtime_float();
            
                $weawp_settings = $this->weawp_get_settings();

                $weawp_settings_val_string = $weawp_settings['settings'];
                $weawp_settings_val = json_decode($weawp_settings_val_string, true);
                $weawp_themes_variants = $weawp_settings_val['ThemesVariants'];
                $theme_variant_active = [];

                foreach($weawp_themes_variants as  $item) {
                    if ($item['selected'] == 1) {
                        $theme_variant_active = $item;
                    }
                }

                if (empty($theme_variant_active)) {
                    $default_theme = 'Theme1';
                    foreach($weawp_themes_variants as  $item) {
                        if ( str_replace(' ', '', $item['name']) == str_replace(' ', '',$default_theme) ) {
                            $theme_variant_active = $item;
                        }
                    }
                }
            
                $data_total_count = $weawp_settings['data_total_count'];

                $weawp_data = array();
                $weawp_data['data'] = array();
                if ((int)$data_total_count <= (int)$theme_variant_active['processingTypeServerSideLimit']) {
                    $weawp_data['data'] = $this->weawp_get_application_data($theme_variant_active);
                    $weawp_data['time_plugin_load_data'] = weawp_microtime_float() - $timeProbe;
                }

                $varHTML = [];
                $varHTML[] = '<script> var weawp_settings =' . json_encode($weawp_settings) . '; var weawp_data =' . json_encode($weawp_data) . ' </script>';
                $varHTML[] = '<div style=><div id="weawp_search"></div></div>';

                echo implode($varHTML);
                add_action( 'admin_enqueue_scripts', 'load_scripts' );

                function weawp_cron_daily_add() {
                    if( !wp_next_scheduled( 'weawp_cron_daily_fnc' ) ) {  
                    wp_schedule_event( time(), 'daily', 'weawp_cron_daily_fnc' );  
                    }
                }
                add_action('wp', 'weawp_cron_daily_add');

                function weawp_cron_hourly_add() {
                    if( !wp_next_scheduled( 'weawp_cron_hourly_fnc' ) ) {  
                    wp_schedule_event( time(), 'hourly', 'weawp_cron_hourly_fnc' );  
                    }
                }
                add_action('wp', 'weawp_cron_hourly_add');

            // } catch (err) {

            // }

        }


        public function weawp_cron_daily_fnc() {
            
            global $wpdb;
            $SQL = "INSERT INTO " . $wpdb->prefix . "weawp_search (name) VALUES (%s)";
            $db = $wpdb->get_results($wpdb->prepare($SQL, 'daily_cron_test'));

        }

        public function weawp_cron_hourly_fnc() {

            global $wpdb;
            $SQL = "INSERT INTO " . $wpdb->prefix . "weawp_search (name) VALUES (%s)";
            $db = $wpdb->get_results($wpdb->prepare($SQL, 'hourly_cron_test'));

        }

        private function weawp_get_application_data($theme_variant_active)
        {
       
            $search_in_description = true;
            $display_product_categories = true;
            $display_product_attributes = true;

            $i = 0;
            $product_cat = get_terms('product_cat');
            $product_cat = array_values($product_cat);

            $product_tag = get_terms( 'product_tag' );
    
            $categories = get_categories(["hide_empty" => 0]);
            $categories_ar = array();

            foreach ($categories as $category) {
                $item = array();
                $item['term_id'] = $category->term_id;
                $item['id'] = $category->term_id;
                $item['name'] = $category->name;
                $item['url'] = get_category_link($category->term_id);
                $categories_ar[] = $item;
            }

            $tags = get_tags(["hide_empty" => 0]);
            $tags_ar = array();

            foreach ($tags as $tag) {
                $item = array();
                $item['term_id'] = $tag->term_id;
                $item['id'] = $tag->term_id;
                $item['name'] = $tag->name;
                $item['url'] = get_tag_link($tag->term_id);
                $tags_ar[] = $item;
            }
        
            $args_product = [
                'numberposts' => 100000, 
                'post_type' => 'product',
                'post_status' => 'publish',
                'posts_per_page' > -1,
                'orderby' => 'date',
                'order' => 'DESC',  
            ];

            global $product;
            $products = get_posts($args_product);
            $product_count = count($products);
            
            $data = [];
            $i = 0;

            foreach ($products as $product) {
                $product_id = $product->ID;
                $product = wc_get_product($product_id);

                $data[$i]['id'] = $product_id;
                $data[$i]['name'] = esc_attr($product->get_name());
                $data[$i]['type'] = 'product';
                $data[$i]['is_featured'] = esc_attr($product->get_featured());
                $product_cat_ids = wc_get_product_term_ids( $product_id, 'product_cat' );
                $product_tag_ids = wc_get_product_term_ids( $product_id, 'product_tag' );

                $data[$i]['categories'] = $product_cat_ids; // TODO: check
                $data[$i]['tags'] = $product_tag_ids;
        
                if ($search_in_description) {
                    $data[$i]['content'] = esc_attr($product->get_description());
                } else {
                    $data[$i]['content'] = substr(esc_attr($product->get_description()), 0, 250);
                }

                $data[$i]['link'] = get_permalink($product_id);
                $data[$i]['sku'] = $product->get_sku();
                $data[$i]['price'] = $product->get_price();
                $data[$i]['price'] = $product->get_regular_price();
                if( $product->is_on_sale() ) {
                    $data[$i]['sale_price'] = true;
                    $data[$i]['sale_price_value'] = $product->get_sale_price();
                    $data[$i]['date_on_sale_from'] = $product->get_date_on_sale_from();
                    $data[$i]['date_on_sale_to'] = $product->get_date_on_sale_to();
                } else {
                    $data[$i]['sale_price'] = false;
                    $data[$i]['sale_price_value'] = '';
                }
                $data[$i]['post_date'] = date($product->get_date_created());
                $data[$i]['stock_status'] = $product->get_stock_status();
                $data[$i]['stock_quantity'] = $product->get_stock_quantity();
                $data[$i]['reviews_allowed'] = $product->get_reviews_allowed();
                $data[$i]['rating_items'] = !empty(count($product->get_rating_counts())) ? count($product->get_rating_counts()) : '';
                $data[$i]['rating'] = $product->get_average_rating();
                $data[$i]['featured_image']['thumbnail'] = get_the_post_thumbnail_url($product_id, 'thumbnail');
                $data[$i]['featured_image']['medium'] = get_the_post_thumbnail_url($product_id, 'medium');
                $data[$i]['featured_image']['large'] = get_the_post_thumbnail_url($product_id, 'large');
                    $thumbnail_id = get_post_thumbnail_id($product_id);
                $data[$i]['featured_image_alt'] = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
                $data[$i]['add_to_cart_url'] = $product->add_to_cart_url();


                if ($display_product_attributes) {
                    $attribute_items = [];
                    $product_attributes = $product->get_attributes();
                    foreach ( $product_attributes as $attribute ) {
                        $attribute->name_without_prefix_pa = str_replace('pa_', "", (string)$attribute['name']);
                        $attribute_items[ $attribute->name_without_prefix_pa] = explode(',',$product->get_attribute($attribute['name']));
                    }
                    $data[$i]['attributes'] = $attribute_items;
                }
                

                if ($display_product_categories) {
                    $product_cat_ids = wc_get_product_term_ids( $product_id, 'product_cat' );
                    foreach($product_cat_ids as $id) {
                        $term = get_term($id);
                        if (!empty($term)) {
                            $data[$i]['product_category'][] = ['name'=> $term->name, 'id'=> $id];
                        }
                    }
                }
                $i++;
            }

            $args_blog = [
                'post_status' => 'publish',
                'posts_per_page' > -1,
                'orderby' => 'date',
                'order' => 'DESC',  
            ];

            $blogPosts = get_posts($args_blog);
            $blogPostsFiltered = array();

            foreach ($blogPosts as $blogPost) {
                $item = array();
                $item['id'] = $blogPost->ID;
                $item['name'] = $blogPost->post_title;
                $item['type'] = 'blog post';
                if ($search_in_description) {
                    $item['content'] = esc_html($blogPost->post_content);
                } else {
                    $item['content'] = substr(esc_html($blogPost->post_content), 0, 250);
                }
                $item['date'] = $blogPost->post_date;
                $item['link'] = get_permalink($blogPost->ID);
                $item['featured_image'] = get_the_post_thumbnail_url($blogPost->ID, 'thumbnail');
                $blogPostsFiltered[] = $item;

            }

            $pageAr = get_pages([
                'post_type' => 'page',
                'post_status'  => 'publish',
                'orderby' => 'date',
                'order' => 'DESC',  
            ]);

            $pageFilteredAr = array();

            foreach ($pageAr as $page) {
                $item = array();
                $item['id'] = $page->ID;
                $item['name'] = $page->post_title;
                $item['type'] = 'page';
                
                if ($search_in_description) {
                    $item['content'] = esc_html($page->post_content);
                } else {
                    $item['content'] = substr(esc_html($page->post_content), 0, 250);
                }
                $item['date'] = $page->post_date;
                $item['link'] = get_permalink($page->ID);
                $item['featured_image'] = get_the_post_thumbnail_url($page->ID, 'thumbnail');
                $pageFilteredAr[] = $item;
            }

            $response = array();
            $response['data'] = $data;
            $response['blog_posts'] = $blogPostsFiltered;
            $response['pages'] = $pageFilteredAr;
            $response['data_count'] = $product_count;
            $response['product_categories'] = $product_cat;
            $response['product_tags'] = $product_tag;
            $response['categories'] = $categories_ar;
            $response['tags'] = $tags_ar;

            return $response;

        }

        private function weawp_get_settings() {

            $date_now = date("Y-m-d");
            $prmn = $date_now > '2023-08-31' ? '' : 'prmn_on';

            $fpvr = '';
            
            global $wpdb;
            $settings = $wpdb->get_results("SELECT value FROM " . $wpdb->prefix . "weawp_search WHERE name = 'default-settings'");
            $index_applied = $wpdb->get_results("SELECT value FROM " . $wpdb->prefix . "weawp_search WHERE name = 'database-indexes-applied'");
            $analytics_history_delete = $wpdb->get_results("DELETE FROM  " . $wpdb->prefix . "weawp_search_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)");
            $analytics = $wpdb->get_results("SELECT value FROM " . $wpdb->prefix . 'weawp_search'. " WHERE name = 'analytics' ORDER BY created_at DESC");

            $wc_options = get_option('woocommerce_permalinks');

            $output = array();
            $output['wpNonce'] = wp_create_nonce( 'wp_rest' );
            $output['settings'] = $settings[0]->value;
            $output['attributes'] = $this->weawp_get_wp_attributes();
            $output['data_total_count'] = $this->weawp_get_data_total_count();
            $output['index_applied'] = $index_applied[0]->value;
            $output['prmn'] = $prmn;
            $output['analytics'] = $analytics[0]->value;
            $output['fpvr'] = $fpvr;
            $output['wp_custom_product_category_base_url'] = $wc_options['category_base'];
            $output['wp_custom_product_tag_base_url'] = $wc_options['tag_base'];

            $output['currency'] = get_woocommerce_currency_symbol();

            return $output;
        }

        private function weawp_get_wp_attributes() {
            
            global $wpdb;
            $SQL =  "SELECT distinct taxonomy FROM wp_term_taxonomy WHERE taxonomy LIKE 'pa_%'" ;
            $attribute_terms = $wpdb->get_results($wpdb->prepare($SQL));

            $attributes = array();

            foreach($attribute_terms as $attribute_term) {
                $item = array();
                $item['label'] = $attribute_term->taxonomy;
                $item['name'] = str_replace("pa_", "", $attribute_term->taxonomy);
                $attributes[] = $item; 
            }
           
            return $attributes;

        }

        private function weawp_get_data_total_count() {
            global $wpdb;

            $SQL  = " SELECT count(ID) as count ";
            $SQL .= " FROM " . $wpdb->prefix . "posts";
            $SQL .= " WHERE post_type in('product', 'post', 'page') ";
            $SQL .= " AND post_status = 'publish' ";
            
            $db_response = $wpdb->get_results($SQL);
            $data_total_count = $db_response[0]->count;

            return $data_total_count;
        }

        function load_scripts() {
            wp_enqueue_script( 'wp-react-kickoff', weawp_URL . 'admin/js/weawp_search.min.js', [ 'jquery', 'wp-element' ], wp_rand(), true );
            wp_enqueue_style( 'style',  weawp_URL . 'admin/css/weawp_search.min.css', get_stylesheet_uri() );
        }

    }
}

new class_weawp_admin();