<?php
/**
 * Plugin Name: WebAriadne
 * Description: The WordPress search plugin with live search autocomplete function. It gives visitors of the website an option to search for relevant information in blog posts, pages, products, categories and attributes. 
 * 
 * Author:       WebAriadne
 * Plugin URI:   https://nx.webariadne.com
 * Version:      0.93
 * License:      GPLv3
 * License URI:  https://www.gnu.org/licenses/gpl-3.0.html
 * Requires at least: 5.3
 * Requires PHP: 7.1
 */


if (!defined('ABSPATH')) {
    exit;
}

    if ( !function_exists( 'weawp_get_application_data' ) ) {
        function weawp_get_application_data($theme_variant_active)
        {

            $search_content = false;
            $display_product_attributes = true;
            $display_product_categories = true;

            $product_cat = get_terms('product_cat');
            $product_cat = array_values($product_cat);

            $product_tag = get_terms( 'product_tag' );

            $categories = get_categories(["hide_empty" => 0]);
            $categories_ar = array();

            foreach ($categories as $category) {
                $item = array();
                $item['term_id'] = $category->term_id;
                $item['id'] = $category->term_id;
                $item['name'] = $category->name;
                $item['url'] = get_category_link($category->term_id);
                $categories_ar[] = $item;
            }

            $tags = get_tags(["hide_empty" => 0]);
            $tags_ar = array();

            foreach ($tags as $tag) {
                $item = array();
                $item['term_id'] = $tag->term_id;
                $item['id'] = $tag->term_id;
                $item['name'] = $tag->name;
                $item['url'] = get_tag_link($tag->term_id);
                $tags_ar[] = $item;
            }
            
            $args_product = [
                'numberposts' => 100000, 
                'post_type' => 'product',
                'post_status' => 'publish',
                'posts_per_page' > -1,
                'orderby' => 'date',
                'order' => 'DESC',  
            ];

            global $product;
            $products = get_posts($args_product);
            $product_count = count($products);
            
            $data = [];
            $i = 0;

            foreach ($products as $product) {
                $product_id = $product->ID;
                $product = wc_get_product($product_id);

                $data[$i]['id'] = $product_id;
                $data[$i]['name'] = esc_attr($product->get_name());
                $data[$i]['type'] = 'product';
                $data[$i]['is_featured'] = esc_attr($product->get_featured());
                $product_cat_ids = wc_get_product_term_ids( $product_id, 'product_cat' );
                $product_tag_ids = wc_get_product_term_ids( $product_id, 'product_tag' );

                $data[$i]['categories'] = $product_cat_ids;
                $data[$i]['tags'] = $product_tag_ids;

                if ($search_content) {
                    $data[$i]['content'] = esc_attr($product->get_description());
                } else {
                    $data[$i]['content'] = substr(esc_attr($product->get_description()), 0, 250);
                }

                $data[$i]['link'] = get_permalink($product_id);
                $data[$i]['sku'] = $product->get_sku();
                $data[$i]['price'] = $product->get_price();
                $data[$i]['price'] = $product->get_regular_price();
                if( $product->is_on_sale() ) {
                    $data[$i]['sale_price'] = true;
                    $data[$i]['sale_price_value'] = $product->get_sale_price();
                    $data[$i]['date_on_sale_from'] = $product->get_date_on_sale_from();
                    $data[$i]['date_on_sale_to'] = $product->get_date_on_sale_to();
                } else {
                    $data[$i]['sale_price'] = false;
                    $data[$i]['sale_price_value'] = '';
                }
                $data[$i]['post_date'] = date($product->get_date_created());
                $data[$i]['stock_status'] = $product->get_stock_status();
                $data[$i]['stock_quantity'] = $product->get_stock_quantity();
                $data[$i]['reviews_allowed'] = $product->get_reviews_allowed();
                $data[$i]['rating_items'] = !empty(count($product->get_rating_counts())) ? count($product->get_rating_counts()) : '';
                $data[$i]['rating'] = $product->get_average_rating();
                $data[$i]['featured_image']['thumbnail'] = get_the_post_thumbnail_url($product_id, 'thumbnail');
                $data[$i]['featured_image']['medium'] = get_the_post_thumbnail_url($product_id, 'medium');
                $data[$i]['featured_image']['large'] = get_the_post_thumbnail_url($product_id, 'large');
                $data[$i]['add_to_cart_url'] = $product->add_to_cart_url();

                if ($display_product_attributes) {
                    $attribute_items = [];
                    $product_attributes = $product->get_attributes();
                    foreach ( $product_attributes as $attribute ) {
                        $attribute->name_without_prefix_pa = str_replace('pa_', "", (string)$attribute['name']);
                        $attribute_items[ $attribute->name_without_prefix_pa] = explode(',',$product->get_attribute($attribute['name']));
                    }
                    $data[$i]['attributes'] = $attribute_items;
                }

                if ($display_product_categories) {
                    $product_cat_ids = wc_get_product_term_ids( $product_id, 'product_cat' );
                    foreach($product_cat_ids as $id) {
                        $term = get_term($id);
                        if (!empty($term)) {
                            $data[$i]['product_category'][] = ['name'=> $term->name, 'id'=> $id];
                        }
                    }
                }
                
                $i++;
            }

            $args_blog = [
                'post_status' => 'publish',
                'posts_per_page' > -1,
                'orderby' => 'date',
                'order' => 'DESC',  
            ];

            $blogPosts = get_posts($args_blog);
            $blogPostsFiltered = array();

            foreach ($blogPosts as $blogPost) {
                $item = array();
                $item['id'] = $blogPost->ID;
                $item['name'] = $blogPost->post_title;
                $item['type'] = 'blog post';
                if ($search_content) {
                    $item['content'] = esc_html($blogPost->post_content);
                } else {
                    $item['content'] = substr(esc_html($blogPost->post_content), 0, 250);
                }
                $item['date'] = $blogPost->post_date;
                $item['link'] = get_permalink($blogPost->ID);
                $item['featured_image'] = get_the_post_thumbnail_url($blogPost->ID, 'thumbnail');
                $blogPostsFiltered[] = $item;
            }

            $pageAr = get_pages([
                'post_type' => 'page',
                'post_status'  => 'publish',
                'orderby' => 'date',
                'order' => 'DESC',  
            ]);

            $pageFilteredAr = array();

            foreach ($pageAr as $page) {

                $item = array();
                $item['id'] = $page->ID;
                $item['name'] = $page->post_title;
                $item['type'] = 'page';
                
                if ($search_content) {
                    $item['content'] = esc_html($page->post_content);
                } else {
                    $item['content'] = substr(esc_html($page->post_content), 0, 250);
                }
                $item['date'] = $page->post_date;
                $item['link'] = get_permalink($page->ID);
                $item['featured_image'] = get_the_post_thumbnail_url($page->ID, 'thumbnail');

                $pageFilteredAr[] = $item;
            }

            $response = array();
            $response['data'] = $data;
            $response['blog_posts'] = $blogPostsFiltered;
            $response['pages'] = $pageFilteredAr;
            $response['data_count'] = $product_count;
            $response['product_categories'] = $product_cat;
            $response['product_tags'] = $product_tag;
            $response['categories'] = $categories_ar;
            $response['tags'] = $tags_ar;

            return $response;
        }
    }

    if ( !function_exists( 'weawp_get_settings' ) ) {
        function weawp_get_settings() {

            $date_now = date("Y-m-d");
            $prmn = $date_now > '2023-09-30' ? '' : 'prmn_on';
            $fpvr = '';

            global $wpdb;
            $settings = $wpdb->get_results("SELECT value FROM " . $wpdb->prefix . 'weawp_search'. " WHERE name = 'default-settings'");
            $index_applied = $wpdb->get_results("SELECT value FROM " . $wpdb->prefix . 'weawp_search'. " WHERE name = 'database-indexes-applied'");
            $analytics = $wpdb->get_results("SELECT value FROM " . $wpdb->prefix . 'weawp_search'. " WHERE name = 'analytics'");

            $wc_options = get_option('woocommerce_permalinks');

            $output = array();

            $output['wpNonce'] = wp_create_nonce( 'wp_rest' );
            $output['settings'] = $settings[0]->value;
            $output['attributes'] = weawp_get_wp_attributes();
            $output['data_total_count'] = weawp_get_data_total_count();
            $output['index_applied'] = $index_applied[0]->value;
            $output['analytics'] = $analytics[0]->value;
            $output['wp_custom_product_category_base_url'] = $wc_options['category_base'];
            $output['wp_custom_product_tag_base_url'] = $wc_options['tag_base'];
            $output['currency'] = get_woocommerce_currency_symbol();
            $output['prmn'] = $prmn;
            $output['fpvr'] = $fpvr;
    
            return $output;
        }
    }

    if ( !function_exists( 'weawp_get_wp_attributes' ) ) {

        function weawp_get_wp_attributes() {
            $attributes = array();
            foreach( wc_get_attribute_taxonomies() as $attribute ) {
                $item = array();
                $item['label'] = $attribute->attribute_label; 
                $item['name'] = $attribute->attribute_name; 
                $attributes[] = $item; 
            }
            return $attributes;
        }
    }

    if ( !function_exists( 'weawp_get_data_total_count' ) ) {
        function weawp_get_data_total_count() {
            global $wpdb;

            $SQL  = " SELECT count(ID) as count ";
            $SQL .= " FROM " . $wpdb->prefix . "posts";
            $SQL .= " WHERE post_status = 'publish' ";
            $SQL .= " AND post_type in('product', 'post', 'page') ";
            
            $db_response = $wpdb->get_results($SQL);
            $data_total_count = $db_response[0]->count;

            return $data_total_count;
        }
    }

define ( 'weawp_PATH', trailingslashit( plugin_dir_path( __FILE__ ) ) );
define ( 'weawp_URL', trailingslashit( plugins_url( '/', __FILE__ ) ) );

global $jal_db_version;
$jal_db_version = '1.0';

if ( !function_exists( 'install_activation' ) ) {

    function install_activation() {
        global $wpdb;
        global $jal_db_version;

        $table_weawp_search = $wpdb->prefix . 'weawp_search';
        $charset_collate = $wpdb->get_charset_collate();

        $SQL = "CREATE TABLE " . $table_weawp_search . " (
            id mediumint NOT NULL AUTO_INCREMENT,
            name tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
            value text COLLATE utf8mb4_unicode_520_ci,
            type varchar(47) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate; ";

    
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $SQL );

            $wpdb->insert( 
                $table_weawp_search, 
                array( 
                    'name' => 'default-settings', 
                    'value' => '{"ThemesVariants":[{"name":"Theme1","type":"theme","shortCode":"[weawp]","selected":1,"processingTypeServerSideLimit":"1500","searchInDescription":0,"highlightSearchTerm":1,"Responsivity":{"mobileBP":"1200"},"Initial Page":{"display":1},"Search Bar":{"placeholderText":"website search ","icon":{"display":0},"speechRecognition":{"display":1,"language":{"value":"en-GB","label":"English (UK)"}}},"Links":{"websiteSerachMaxLinks":"25","display":"1"},"Cards":{"websiteSerachMaxCards":"15","Price":{"display":1}},"Attributes":[{"label":"Brand","name":"brand","display":1,"search":1},{"label":"Color","name":"color","display":1,"search":1}],"Content Type":[{"name":"Products","card":1,"order_id":0,"active":1,"displayOnlyInStock":0,"searchBySku":1,"displaySku":1,"searchByProductCategory":1,"displayProductCategory":1,"searchInContent":1,"displayProductContentLines":2,"displayProductCategories":1,"searchInProductCategory":1,"displayContentRows":2,"chosen":false},{"name":"Blog","card":1,"order_id":1,"active":1,"chosen":false},{"name":"Pages","card":1,"order_id":2,"active":1,"chosen":false},{"name":"Product Categories","card":0,"order_id":2,"initialPageOrder":0,"active":1,"data":[{"term_id":46,"name":"Outdoor","slug":"outdoor","term_group":0,"term_taxonomy_id":46,"taxonomy":"product_cat","description":"","parent":0,"count":155,"filter":"raw","type":"product_category","id":46,"url":"/product-category/outdoor","intialWindow":1},{"term_id":44,"name":"Outdoor Tents","slug":"outdoor-revolution-tents","term_group":0,"term_taxonomy_id":44,"taxonomy":"product_cat","description":"","parent":0,"count":146,"filter":"raw","type":"product_category","id":44,"url":"/product-category/outdoor-revolution-tents","intialWindow":1},{"term_id":16,"name":"Product Category 01","slug":"product-category-01","term_group":0,"term_taxonomy_id":16,"taxonomy":"product_cat","description":"","parent":0,"count":291,"filter":"raw","type":"product_category","id":16,"url":"/product-category/product-category-01","intialWindow":0},{"term_id":17,"name":"Product Category 02","slug":"product-category-02","term_group":0,"term_taxonomy_id":17,"taxonomy":"product_cat","description":"","parent":0,"count":271,"filter":"raw","type":"product_category","id":17,"url":"/product-category/product-category-02","intialWindow":0},{"term_id":41,"name":"Product Category 03","slug":"product-category-03","term_group":0,"term_taxonomy_id":41,"taxonomy":"product_cat","description":"","parent":0,"count":150,"filter":"raw","type":"product_category","id":41,"url":"/product-category/product-category-03","intialWindow":0}],"initialPageOrderId":0,"chosen":false,"initialPageActive":0},{"name":"Product Tags","card":0,"order_id":0,"active":1,"data":[{"term_id":18,"name":"tag 1","slug":"tag-1","term_group":0,"term_taxonomy_id":18,"taxonomy":"product_tag","description":"","parent":0,"count":443,"filter":"raw","id":18,"type":"product_tag","url":"/product-tag/tag-1"},{"term_id":19,"name":"tag 2","slug":"tag-2","term_group":0,"term_taxonomy_id":19,"taxonomy":"product_tag","description":"","parent":0,"count":446,"filter":"raw","id":19,"type":"product_tag","url":"/product-tag/tag-2"}],"chosen":false,"initialPageOrderId":2,"initialPageActive":0},{"name":"Categories","card":0,"order_id":1,"active":1,"initialPageOrder":1,"data":[{"term_id":25,"id":25,"name":"Category 1","url":"http://wo2.test/category/category-1/","type":"category","intialWindow":1},{"term_id":26,"id":26,"name":"Category 2","url":"http://wo2.test/category/category-2/","type":"category","intialWindow":0}],"initialPageOrderId":1,"chosen":false,"initialPageActive":1},{"name":"Tags","card":0,"order_id":3,"active":1,"data":[{"term_id":27,"id":27,"name":"Tag 1","url":"http://wo2.test/tag/tag-1/","type":"tag"},{"term_id":28,"id":28,"name":"Tag 2","url":"http://wo2.test/tag/tag-2/","type":"tag"},{"term_id":29,"id":29,"name":"Tag 3","url":"http://wo2.test/tag/tag-3/","type":"tag"}],"initialPageOrderId":3,"chosen":false,"initialPageActive":1}],"Bottom Link":{"text":"View all #n results","link":"/shop"},"Shortcuts":{"start searching":[{"value":"space","label":"space bar"},{"value":"ctrl+alt","label":"ctrl+alt"}]},"date":"2023-07-01 19:05:12","style":{"Search Bar":{"Background":{"block":"#dce7e9"},"Text":{"size":"14","block":"#2d2d2d","placeholder block":"#adbfbd"},"Spacing":{"paddingTop":8,"paddingRight":5,"paddingBottom":8,"paddingLeft":"22","height":"43","widthDesktop":"331","widthMobile":"96"},"Border":{"radius":"24","width":"1","block":"#acacac"}},"Result Window":{"Background":{"block":"#ffffff"},"Text":{"size":"14","block":"#859d9c"},"Spacing":{"paddingTop":9,"paddingRight":8,"paddingBottom":7,"paddingLeft":8,"maxWidthDesktop":"879","maxWidthMobile":"94","maxHeightDesktop":"486"},"Border":{"radius":"0","width":"0","block":"#cccccc"}},"Search Result Card":{"Background":{"block":"#ffffff","highlighted-block":"#f5f5f8"},"Title":{"size":"15","block":"#5c5c5c","highlighted-block":"#4a5056","search-match-block":"#DEE3F5"},"Text":{"size":"12","block":"#a9a9a9","highlighted-block":"#707479","search-match-block":"#DEE3F5"},"Spacing":{"heightDesktop":"96","heightMobile":106,"paddingTop":"8","paddingRight":5,"paddingBottom":8,"paddingLeft":"16"},"Image":{"display":1,"width":"89","height":"89"},"Border":{"width":"0","block":"#cccccc"}},"Search Result Link":{"Background":{"block":"#ffffff","highlighted-block":"#efeff4"},"Title":{"size":"16","block":"#424242","background-block":"#4a5056","search-match-block":"#DEE3F5"},"Text":{"size":"14","block":"#656565","highlighted-block":"#707479","search-match-block":"#DEE3F5"},"Spacing":{"heightDesktop":"37","heightMobile":"37"}},"Bottom Link":{"Background":{"block":"#eeebf0"},"Text":{"size":15,"block":"#354140"},"Spacing":{"heightDesktop":40}},"General":{"Font":{"FontFamily":{"label":"weawp plugin","value":"Poppins"}},"Alignement":{"horizontal":"center"},"Spacing":{"marginTop":0,"marginBottom":0}}},"parentTheme":""},{"name":"Autocomplete","type":"theme","shortCode":"[weawp name=\"autocomplete\"]","selected":0,"processingTypeServerSideLimit":"1500","searchInDescription":1,"highlightSearchTerm":1,"Responsivity":{"mobileBP":"1200"},"Initial Page":{"display":1},"Search Bar":{"placeholderText":"website search   press: %s","icon":{"display":1},"speechRecognition":{"display":1,"language":{"value":"en-US","label":"English (US)"}}},"Links":{"websiteSerachMaxLinks":"25","display":0},"Cards":{"websiteSerachMaxCards":"15","Price":{"display":0}},"Attributes":[{"label":"Brand","name":"brand","display":0,"search":1},{"label":"Color","name":"color","display":0,"search":1}],"Content Type":[{"name":"Products","card":1,"order_id":0,"active":1,"displayOnlyInStock":0,"searchBySku":1,"displaySku":0,"searchByProductCategory":1,"displayProductCategory":1,"searchInContent":1,"displayProductContentLines":2,"displayProductCategories":0,"searchInProductCategory":1,"displayContentRows":0},{"name":"Blog","card":1,"order_id":1,"active":1,"chosen":false},{"name":"Pages","card":1,"order_id":2,"active":1},{"name":"Product Categories","card":0,"order_id":2,"initialPageOrder":0,"active":1,"data":[{"term_id":46,"name":"Outdoor","slug":"outdoor","term_group":0,"term_taxonomy_id":46,"taxonomy":"product_cat","description":"","parent":0,"count":155,"filter":"raw","type":"product_category","id":46,"url":"/product-category/outdoor","intialWindow":1},{"term_id":44,"name":"Outdoor Tents","slug":"outdoor-revolution-tents","term_group":0,"term_taxonomy_id":44,"taxonomy":"product_cat","description":"","parent":0,"count":146,"filter":"raw","type":"product_category","id":44,"url":"/product-category/outdoor-revolution-tents","intialWindow":1},{"term_id":16,"name":"Product Category 01","slug":"product-category-01","term_group":0,"term_taxonomy_id":16,"taxonomy":"product_cat","description":"","parent":0,"count":291,"filter":"raw","type":"product_category","id":16,"url":"/product-category/product-category-01","intialWindow":0},{"term_id":17,"name":"Product Category 02","slug":"product-category-02","term_group":0,"term_taxonomy_id":17,"taxonomy":"product_cat","description":"","parent":0,"count":271,"filter":"raw","type":"product_category","id":17,"url":"/product-category/product-category-02","intialWindow":0},{"term_id":41,"name":"Product Category 03","slug":"product-category-03","term_group":0,"term_taxonomy_id":41,"taxonomy":"product_cat","description":"","parent":0,"count":150,"filter":"raw","type":"product_category","id":41,"url":"/product-category/product-category-03","intialWindow":0}],"initialPageOrderId":0,"chosen":false,"initialPageActive":0},{"name":"Product Tags","card":0,"order_id":0,"active":1,"data":[{"term_id":18,"name":"tag 1","slug":"tag-1","term_group":0,"term_taxonomy_id":18,"taxonomy":"product_tag","description":"","parent":0,"count":443,"filter":"raw","id":18,"type":"product_tag","url":"/product-tag/tag-1"},{"term_id":19,"name":"tag 2","slug":"tag-2","term_group":0,"term_taxonomy_id":19,"taxonomy":"product_tag","description":"","parent":0,"count":446,"filter":"raw","id":19,"type":"product_tag","url":"/product-tag/tag-2"}],"chosen":false,"initialPageOrderId":2,"initialPageActive":0},{"name":"Categories","card":0,"order_id":1,"active":1,"initialPageOrder":1,"data":[{"term_id":25,"id":25,"name":"Category 1","url":"http://wo2.test/category/category-1/","type":"category","intialWindow":1},{"term_id":26,"id":26,"name":"Category 2","url":"http://wo2.test/category/category-2/","type":"category","intialWindow":0}],"initialPageOrderId":1,"chosen":false,"initialPageActive":1},{"name":"Tags","card":0,"order_id":3,"active":1,"data":[{"term_id":27,"id":27,"name":"Tag 1","url":"http://wo2.test/tag/tag-1/","type":"tag"},{"term_id":28,"id":28,"name":"Tag 2","url":"http://wo2.test/tag/tag-2/","type":"tag"},{"term_id":29,"id":29,"name":"Tag 3","url":"http://wo2.test/tag/tag-3/","type":"tag"}],"initialPageOrderId":3,"chosen":false,"initialPageActive":1}],"Bottom Link":{"text":"View all #n results","link":"/shop"},"Shortcuts":{"start searching":[{"value":"space","label":"space bar"},{"value":"ctrl+space","label":"ctrl+space"}]},"date":"2023-07-01 19:05:12","style":{"Search Bar":{"Background":{"block":"#dce7e9"},"Text":{"size":"14","block":"#2d2d2d","placeholder block":"#adbfbd"},"Spacing":{"paddingTop":8,"paddingRight":5,"paddingBottom":8,"paddingLeft":"22","height":"43","widthDesktop":"320","widthMobile":"96"},"Border":{"radius":"7","width":"1","block":"#b0aebc"}},"Result Window":{"Background":{"block":"#ffffff"},"Text":{"size":"14","block":"#678988"},"Spacing":{"paddingTop":9,"paddingRight":8,"paddingBottom":7,"paddingLeft":8,"maxWidthDesktop":"432","maxWidthMobile":"90","maxHeightDesktop":"305"},"Border":{"radius":5,"width":"0","block":"#cccccc"}},"Search Result Card":{"Background":{"block":"#ffffff","highlighted-block":"#f5f5f8"},"Title":{"size":"14","block":"#354140","highlighted-block":"#4a5056","search-match-block":"#DEE3F5"},"Text":{"size":"12","block":"#93939e","highlighted-block":"#707479","search-match-block":"#DEE3F5"},"Spacing":{"heightDesktop":"34","heightMobile":"34","paddingTop":"8","paddingRight":5,"paddingBottom":8,"paddingLeft":"16"},"Image":{"display":0,"width":"89","height":"89"},"Border":{"width":"0","block":"#cccccc"}},"Search Result Link":{"Background":{"block":"#ffffff","highlighted-block":"#efeff4"},"Title":{"size":"16","block":"#424242","background-block":"#4a5056","search-match-block":"#DEE3F5"},"Text":{"size":"14","block":"#656565","highlighted-block":"#707479","search-match-block":"#DEE3F5"},"Spacing":{"heightDesktop":"37","heightMobile":"37"}},"Bottom Link":{"Background":{"block":"#eeebf0"},"Text":{"size":15,"block":"#354140"},"Spacing":{"heightDesktop":"0"}},"General":{"Font":{"FontFamily":{"label":"weawp plugin","value":"Poppins"}},"Alignement":{"horizontal":"center"},"Spacing":{"marginTop":0,"marginBottom":0}}},"parentTheme":"Theme2"},{"name":"Autocomplete Info","type":"variant","shortCode":"[weawp name=\"AutocompleteInfo\"]","selected":0,"processingTypeServerSideLimit":"1500","searchInDescription":1,"highlightSearchTerm":1,"Responsivity":{"mobileBP":"1200"},"Initial Page":{"display":1},"Search Bar":{"placeholderText":"website search   press: %s","icon":{"display":1},"speechRecognition":{"display":1,"language":{"value":"en-US","label":"English (US)"}}},"Links":{"websiteSerachMaxLinks":"25","display":0},"Cards":{"websiteSerachMaxCards":"15","Price":{"display":1}},"Attributes":[{"label":"Brand","name":"brand","display":0,"search":1},{"label":"Color","name":"color","display":0,"search":1}],"Content Type":[{"name":"Products","card":1,"order_id":0,"active":1,"displayOnlyInStock":0,"searchBySku":1,"displaySku":0,"searchByProductCategory":1,"displayProductCategory":1,"searchInContent":1,"displayProductContentLines":2,"displayProductCategories":0,"searchInProductCategory":1,"displayContentRows":1,"chosen":false},{"name":"Blog","card":1,"order_id":1,"active":1},{"name":"Pages","card":1,"order_id":2,"active":1},{"name":"Product Categories","card":0,"order_id":2,"initialPageOrder":0,"active":1,"data":[{"term_id":46,"name":"Outdoor","slug":"outdoor","term_group":0,"term_taxonomy_id":46,"taxonomy":"product_cat","description":"","parent":0,"count":155,"filter":"raw","type":"product_category","id":46,"url":"/product-category/outdoor","intialWindow":1},{"term_id":44,"name":"Outdoor Tents","slug":"outdoor-revolution-tents","term_group":0,"term_taxonomy_id":44,"taxonomy":"product_cat","description":"","parent":0,"count":146,"filter":"raw","type":"product_category","id":44,"url":"/product-category/outdoor-revolution-tents","intialWindow":1},{"term_id":16,"name":"Product Category 01","slug":"product-category-01","term_group":0,"term_taxonomy_id":16,"taxonomy":"product_cat","description":"","parent":0,"count":291,"filter":"raw","type":"product_category","id":16,"url":"/product-category/product-category-01","intialWindow":0},{"term_id":17,"name":"Product Category 02","slug":"product-category-02","term_group":0,"term_taxonomy_id":17,"taxonomy":"product_cat","description":"","parent":0,"count":271,"filter":"raw","type":"product_category","id":17,"url":"/product-category/product-category-02","intialWindow":0},{"term_id":41,"name":"Product Category 03","slug":"product-category-03","term_group":0,"term_taxonomy_id":41,"taxonomy":"product_cat","description":"","parent":0,"count":150,"filter":"raw","type":"product_category","id":41,"url":"/product-category/product-category-03","intialWindow":0}],"initialPageOrderId":0,"chosen":false,"initialPageActive":0},{"name":"Product Tags","card":0,"order_id":0,"active":1,"data":[{"term_id":18,"name":"tag 1","slug":"tag-1","term_group":0,"term_taxonomy_id":18,"taxonomy":"product_tag","description":"","parent":0,"count":443,"filter":"raw","id":18,"type":"product_tag","url":"/product-tag/tag-1"},{"term_id":19,"name":"tag 2","slug":"tag-2","term_group":0,"term_taxonomy_id":19,"taxonomy":"product_tag","description":"","parent":0,"count":446,"filter":"raw","id":19,"type":"product_tag","url":"/product-tag/tag-2"}],"chosen":false,"initialPageOrderId":2,"initialPageActive":0},{"name":"Categories","card":0,"order_id":1,"active":1,"initialPageOrder":1,"data":[{"term_id":25,"id":25,"name":"Category 1","url":"http://wo2.test/category/category-1/","type":"category","intialWindow":1},{"term_id":26,"id":26,"name":"Category 2","url":"http://wo2.test/category/category-2/","type":"category","intialWindow":0}],"initialPageOrderId":1,"chosen":false,"initialPageActive":1},{"name":"Tags","card":0,"order_id":3,"active":1,"data":[{"term_id":27,"id":27,"name":"Tag 1","url":"http://wo2.test/tag/tag-1/","type":"tag"},{"term_id":28,"id":28,"name":"Tag 2","url":"http://wo2.test/tag/tag-2/","type":"tag"},{"term_id":29,"id":29,"name":"Tag 3","url":"http://wo2.test/tag/tag-3/","type":"tag"}],"initialPageOrderId":3,"chosen":false,"initialPageActive":1}],"Bottom Link":{"text":"View all #n results","link":"/shop"},"Shortcuts":{"start searching":[{"value":"space","label":"space bar"},{"value":"ctrl+space","label":"ctrl+space"}]},"date":"2023-07-01 19:05:12","style":{"Search Bar":{"Background":{"block":"#dce7e9"},"Text":{"size":"14","block":"#2d2d2d","placeholder block":"#adbfbd"},"Spacing":{"paddingTop":8,"paddingRight":5,"paddingBottom":8,"paddingLeft":"22","height":"43","widthDesktop":"296","widthMobile":"96"},"Border":{"radius":"7","width":"1","block":"#b0aebc"}},"Result Window":{"Background":{"block":"#ffffff"},"Text":{"size":"14","block":"#678988"},"Spacing":{"paddingTop":9,"paddingRight":8,"paddingBottom":7,"paddingLeft":8,"maxWidthDesktop":"522","maxWidthMobile":98,"maxHeightDesktop":"413"},"Border":{"radius":5,"width":"0","block":"#cccccc"}},"Search Result Card":{"Background":{"block":"#ffffff","highlighted-block":"#f5f5f8"},"Title":{"size":"14","block":"#354140","highlighted-block":"#4a5056","search-match-block":"#DEE3F5"},"Text":{"size":"12","block":"#93939e","highlighted-block":"#707479","search-match-block":"#DEE3F5"},"Spacing":{"heightDesktop":"54","heightMobile":"48","paddingTop":"8","paddingRight":5,"paddingBottom":8,"paddingLeft":"16"},"Image":{"display":1,"width":"47","height":"47"},"Border":{"width":"0","block":"#cccccc"}},"Search Result Link":{"Background":{"block":"#ffffff","highlighted-block":"#efeff4"},"Title":{"size":"16","block":"#424242","background-block":"#4a5056","search-match-block":"#DEE3F5"},"Text":{"size":"14","block":"#656565","highlighted-block":"#707479","search-match-block":"#DEE3F5"},"Spacing":{"heightDesktop":"37","heightMobile":"37"}},"Bottom Link":{"Background":{"block":"#eeebf0"},"Text":{"size":15,"block":"#354140"},"Spacing":{"heightDesktop":"0"}},"General":{"Font":{"FontFamily":{"label":"weawp plugin","value":"Poppins"}},"Alignement":{"horizontal":"center"},"Spacing":{"marginTop":0,"marginBottom":0}}},"parentTheme":"Autocomplete Info"}],"loaded":[]}', 
                    'type' => 'application', 
                )
            );
            
            $wpdb->insert( 
                $table_weawp_search, 
                array( 
                    'name' => 'analytics', 
                    'value' => "{\"active\":1,\"displayTermsWithNoResuts\":1,\"excludeListAnalyticsTerms\":[]}",
                    'type' => 'application', 
                ) 
            );
            $wpdb->insert( 
                $table_weawp_search, 
                array( 
                    'name' => 'database-indexes-applied', 
                    'value' => 0,
                    'type' => 'application', 
                ) 
            );


        $table_weawp_search_log = $wpdb->prefix . 'weawp_search_log';
        
        $SQL = "CREATE TABLE " . $table_weawp_search_log . " (
            `id` int unsigned NOT NULL AUTO_INCREMENT,
            `search_term` varchar(255) DEFAULT NULL,
            `uuid` varchar(63) DEFAULT NULL,
            `displayed_items` varchar(4095) DEFAULT NULL,
            `item_id` int DEFAULT NULL,
            `item_type` varchar(63) DEFAULT NULL,
            `item_link` varchar(2047) DEFAULT NULL,
            `theme_variant` varchar(127) DEFAULT NULL,
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            `deleted_at` datetime DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uuid_UNIQUE` (`uuid`),
            KEY `uuid` (`uuid`),
            KEY `search_term_created_at` (`search_term`,`created_at`) /*!80000 INVISIBLE */,
            KEY `created_at_deleted_at` (`created_at` DESC,`deleted_at`),
            KEY `search_term_created_at_deleted_at` (`search_term`,`created_at` DESC,`deleted_at`)
        ) $charset_collate;";

        dbDelta( $SQL );

        add_option( 'jal_db_version', $jal_db_version );
    }
}

register_activation_hook( __FILE__, 'install_activation' );


/**
 * Plugin admin section
 * load js, css administration scripts
 */
add_action( 'admin_enqueue_scripts', 'load_scripts' );


function load_scripts() {
    wp_enqueue_script( 'wp-react-kickoff', weawp_URL . 'admin/js/weawp_search.min.js', [ 'jquery', 'wp-element' ], wp_rand(), true );
    wp_enqueue_style( 'style',  weawp_URL . 'admin/css/weawp_search.min.css', get_stylesheet_uri() );
    wp_localize_script( 'wp-react-kickoff', 'appLocalizer', [
        'apiUrl' => home_url( '/wp-json' ),
        'nonce' => wp_create_nonce( 'wp_rest' ),
    ] );
}

require_once weawp_PATH . 'classes/class_weawp_admin.php';
require_once weawp_PATH . 'classes/class_weawp_api_routes.php';

function weawp_settings_section_callback(  ) { 
	echo __( 'This section description', 'weawp' );
}

function weawp_options_page(  ) { 
    ?>
    <form action='options.php' method='post'>
        <h2>Web Ariadne search</h2>
        <br>
        <?php
        settings_fields( 'pluginPage' );
        do_settings_sections( 'pluginPage' );
        submit_button();
        ?>
    </form>
    <?php
}

function weawp_plugin_init() {
    $path = "public";

    wp_register_script("weawp_plugin_js", plugins_url($path."/js/weawp_search.min.js", __FILE__), [], "1.2", false);
    wp_register_style("weawp_plugin_css", plugins_url($path."/css/weawp_search.min.css", __FILE__), [], "1.2", "all");
}

add_action( 'init', 'weawp_plugin_init' );

if ( !function_exists( 'weawp_fnc' ) ) {
    function weawp_fnc($atts) {

        $default_theme = 'Theme1';
        $theme_variant_name = !empty($atts['name'] ) ? $atts['name'] : $default_theme;

        wp_enqueue_script("weawp_plugin_js", '1.0', true);
        wp_enqueue_style("weawp_plugin_css");

        $weawp_settings = weawp_get_settings();

        $weawp_settings_val_string = $weawp_settings['settings'];
        $weawp_settings_val = json_decode($weawp_settings_val_string, true);
        $weawp_themes_variants = $weawp_settings_val['ThemesVariants'];
        $theme_variant_active = array();

        foreach($weawp_themes_variants as  $item) {
            if ( str_replace(' ', '', $item['name']) == str_replace(' ', '', $theme_variant_name) ) {
                $theme_variant_active = $item;
            }
        }

        if (!$theme_variant_active) {
            $theme_variant_name = $default_theme;
            foreach($weawp_themes_variants as  $item) {
                if ( str_replace(' ', '', $item['name']) == str_replace(' ', '', $default_theme) ) {
                    $theme_variant_active = $item;
                }
            }
        }

        $data_total_count = $weawp_settings['data_total_count'];

        $weawp_data = array();
        $weawp_data['data'] = array();

        if ((int)$data_total_count <= (int)$theme_variant_active['processingTypeServerSideLimit']) {
            $weawp_data['data'] = weawp_get_application_data($theme_variant_active);

            $weawp_data['shortcode_theme_variant_name'] = $theme_variant_name;
        }

        $varHTML = array();
        $varHTML[] = '<script> var weawp_settings =' . json_encode($weawp_settings) . '; var weawp_data =' . json_encode($weawp_data) . ' </script>';
        $varHTML[] = '<div><div id="weawp_search"></div></div>';

        return implode($varHTML);

    }
}
if ( !function_exists( 'weawp_microtime_float' ) ) {
    function weawp_microtime_float()
    {
        list($usec, $sec) = explode(" ", microtime());
        return ((float)$usec + (float)$sec);
    }
}

add_filter( 'allowed_http_origin', '__return_true' );
add_shortcode( 'weawp', 'weawp_fnc' );