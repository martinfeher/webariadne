<?php

/**
 * /uninstall.php
 *
 * @package WebAriadne
 * @author  WebAriadne
 * @license https://wordpress.org/about/gpl/ GNU General Public License
 * @see     https://wp.webariadne.com/plans
 */

 if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

global $wpdb;

// remove plugin database tables
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}weawp_search" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}weawp_search_log" );

// remove database index type_status_id table posts
$index_name = 'type_status_id';
$SQL = "SHOW INDEX FROM " . $wpdb->prefix . "posts where Key_name = '" . $index_name . "';"; 
$indexdbExists = $wpdb->get_results($SQL);
if (count($indexdbExists) > 0) {
	$wpdb->query( "ALTER TABLE {$wpdb->prefix}posts DROP INDEX type_status_id" ); // removing index 
}